package com.example.android.justjava;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.text.NumberFormat;

import static android.widget.Toast.LENGTH_SHORT;

/**
 * This app displays an order form to order coffee.
 */
public class MainActivity extends AppCompatActivity {

    int quantity = 2;
    int price = 5;
    boolean whipCream = false;
    boolean chocTopping = false;
    String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    private int addWhipCreamChoc(boolean whipCream, boolean chocTopping)
    {
        if(whipCream)
            price = price + 1;

        if(chocTopping)
            price = price + 2;

        return price;
    }

    private void displayMessage(String message)
    {
        TextView orderSummaryTextView = (TextView) findViewById(R.id.orderSummary_text_view);
        orderSummaryTextView.setText(message);
    }

    /**
     * This method is called when the order button is clicked.
     */
    public void submitOrder(View view)
    {
        CheckBox whippedCream = (CheckBox)findViewById(R.id.whip_cream_view);
        CheckBox chocolate = (CheckBox) findViewById(R.id.choc_topping_view);

        chocTopping = chocolate.isChecked();
        whipCream = whippedCream.isChecked();

        price = addWhipCreamChoc(whipCream, chocTopping);

        EditText textField = (EditText) findViewById(R.id.text_field);
        name = textField.getText().toString();

        String summary = createOrderSummary(price, whipCream, chocTopping, name);

     /*   Intent intent = new Intent(Intent.ACTION_SEND);
     // intent.setType("text/plain");
        intent.setData(Uri.parse("mailto:abc@xyz.com")); // only email apps should handle this
        intent.putExtra(Intent.EXTRA_EMAIL, "safina.khanem@gmail.com");
        intent.putExtra(Intent.EXTRA_SUBJECT, "Just Java for " + name);
        intent.putExtra(Intent.EXTRA_TEXT, summary);
        startActivity(intent);
        //if (intent.resolveActivity(getPackageManager()) != null)
        //{
        //} */

        Intent intent = new Intent(Intent.ACTION_SENDTO); // it's not ACTION_SEND
        intent.setType("text/plain");
        intent.putExtra(Intent.EXTRA_SUBJECT, "JustJava order for "+name);
        intent.putExtra(Intent.EXTRA_TEXT, summary);
        intent.setData(Uri.parse("mailto:safina.khanem@gmail.com")); // or just "mailto:" for blank
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); // this will make such that when user returns to your app, your app is displayed, instead of the email app.
        try
        {
            startActivity(intent);
        }
        catch (ActivityNotFoundException e)
        {
        // show message to user
            System.out.println("The exception is here !!!!");
        }
        //startActivity(Intent.createChooser(intent,"Send Email Using: "));

    }

    public void increment(View view)
    {
        if(quantity==10)
        {
            Toast.makeText(this, "The value cannot be more than 10", LENGTH_SHORT).show();
            return;
        }
        else
            quantity++;
        display(quantity);
    }

    public void decrement(View view)
    {
        if(quantity==1)
        {
            Toast.makeText(this, "The value cannot be less than 1", LENGTH_SHORT).show();
            return;
        }
        else
            quantity--;
        display(quantity);
    }

    /**
     * This method displays the given quantity value on the screen.
     */
    private void display(int number)
    {
        TextView quantityTextView = (TextView) findViewById(R.id.quantity_text_view);
        quantityTextView.setText("" + number);
    }


    private String createOrderSummary(int price, boolean whipCream, boolean chocTopping, String name)
    {

        String orderSummary = "Name: " + name + "\nAdd Whip cream? " + whipCream + "\nAdd Chocolate? " + chocTopping +"\nQuantiy: " + quantity + "\nTotal: $" + quantity * price + "\nThank You !";
        //displayMessage(orderSummary);
        return orderSummary;

    }
}